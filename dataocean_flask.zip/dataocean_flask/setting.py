# -*- coding:utf-8 -*-

# dataocean_url = "http://127.0.0.1:8001"
dataocean_url = "http://apitest.digcredit.com"
dataocean_url_data = dataocean_url + "/source/queryinfo/"
dataocean_url_grant = dataocean_url + "/oauth2/token/"
client_id = "jpWstKTB3bqPLWNoocVncCVVHniytPn6ROHy82Ze"
client_secret = "kXXNuP6IOMYr5WxhZihef4Ub6QbOFRPglX0WPPZ5D2sAydh3vDZTCvuMGRFAwlJcu3LoqlQuzs60XE72mxlisrZfhW2DGGCjUHJojkPhiouYrjKrkBj357ThuC61qupk"
des_key = 'sjdguhcphysghcih'

#dataocean mongo cache

# MONGO_HOST = '192.168.1.198'
# MONGO_NAME = 'dataocean'
# MONGO_USERNAME = 'dataocean'
# MONGO_PASSWORD = 'Syph@0918'
MONGO_HOST = '120.27.124.31'
MONGO_NAME = 'dataocean_debug'
MONGO_USERNAME = 'dataocean_debug'
MONGO_PASSWORD = 'Syph@dataocean_debug'
MONGO_PORT = 27017